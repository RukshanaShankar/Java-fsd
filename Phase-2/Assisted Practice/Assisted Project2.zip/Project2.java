package AssistedPractice;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class Project2 {
	public static void main(String [] args)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2","root","starcity2535");  
		     Statement stmt= con.createStatement();
		     stmt.executeUpdate("insert into student(ROLLNO,STDNAME,COURSE,FEES) VALUES(123,'Swetha','Java',10000.00)");
		     System.out.println("New row with values added successfully");

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
