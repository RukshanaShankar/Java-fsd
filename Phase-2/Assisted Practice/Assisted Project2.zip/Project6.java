package AssistedPractice;

import java.sql.*;

public class Project6 {

	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2","root","starcity2535");
			String sql = "INSERT INTO Student(Rollno,Stdname,Course,Fees) VALUES (?, ?, ?, ?)";
	        PreparedStatement prstmt= con.prepareStatement(sql);
	        prstmt.setInt(1, 125);
	        prstmt.setString(2, "diya");
	        prstmt.setString(3, "Java");
	        prstmt.setFloat(4, 25000);
	        prstmt.executeUpdate();
	        System.out.println("Insertion done");
	        String updateQuery = "UPDATE Student SET Course= ? WHERE Stdname= ?";
            PreparedStatement upstmt= con.prepareStatement(updateQuery);
            upstmt.setString(1, "SQL");
            upstmt.setString(2,"diya");
            upstmt.executeUpdate();
            System.out.println("Updation done");
            String deletionQuery = "DELETE FROM Student WHERE Rollno= ?";
            PreparedStatement delstmt= con.prepareStatement(deletionQuery);
            delstmt.setInt(1, 125);
            delstmt.executeUpdate();
            System.out.println("Deletion done");
            prstmt.close();
            upstmt.close();
            delstmt.close();
            con.close();
            
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
