package AssistedPractice;
import java.sql.*;
public class Project1 {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2","root","starcity2535");  
		     if(con!=null)
		     {
		    	 System.out.println("Database connected successfully");
		     }
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
