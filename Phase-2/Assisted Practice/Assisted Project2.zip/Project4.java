package AssistedPractice;
import java.sql.*;
import java.util.Scanner;

class Database
{
	private Connection con;

    public Database() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2", "root", "starcity2535");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertEmployee(String empName, double empSalary) {
        try {
            CallableStatement callableStatement = con.prepareCall("{call insert_employee(?, ?)}");
            callableStatement.setString(1, empName);
            callableStatement.setDouble(2, empSalary);
            callableStatement.execute();
            System.out.println("Employee inserted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

public class Project4 {
      
	public static void main(String[] args) {
		Database dbop = new Database();
		
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter employee name:");
        String empName = sc.nextLine();

        System.out.println("Enter employee salary:");
        double empSalary = Double.parseDouble(sc.nextLine());

        dbop.insertEmployee(empName, empSalary);

        dbop.closeConnection();
        sc.close();
	}

}
