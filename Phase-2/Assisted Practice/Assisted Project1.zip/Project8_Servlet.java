package AssistedProjects;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Project8_Servlet
 */
public class Project8_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Project8_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			response.setContentType("text/html");  
	        PrintWriter pw = response.getWriter();  
	          
	        String n=request.getParameter("userName");  
	        pw.print("Welcome "+n);  
	          
	        //creating form that have invisible textfield 
	        
	        pw.print("<form action='Project8'>");  
	        pw.print("<p style=\"text-align: center;\">");
	        pw.print("	<input type='hidden' name='uname' value='"+n+"'>");  
	        pw.print("	<input type='submit' value='Go to Hello page'>");  
	        pw.print("</p>");
	        pw.print("</form>");  
	        pw.close();  
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
