package java_fsd2;

class Student
{
	int rollno;
	String name;
	int age;
	
	public Student(int rollno,String name,int age)
	{
		super();
		this.rollno=rollno;
		this.name=name;
		this.age=age;
	}
	
	public void isValidVoter(int age) throws InvalidAgeException
	{
		this.age= age;
		
			if(age>=18)
			{
				System.out.println("the student is a valid for voterid");
			}
			else
				{throw new InvalidAgeException();
				
				}
		
	}
}

public class Practice_project5 {
	public static void main(String[] args)
	{
	Student s1 = new Student(123,"abi",14);
	Student s2 = new Student(456,"sai",19);
	
	try
	{
		s1.isValidVoter(14);
		//s2.isValidVoter(19);
	}
	catch(InvalidAgeException e)
	{
		e.printStackTrace();
	}
	finally
	{
		System.out.println("this is finally block");
	}
	}
	
	

}
