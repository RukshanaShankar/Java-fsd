package java_fsd2;

public class Practice_project2 {
	private static Object lock = new Object();
    private static int count = 0;

    static class ThreadA extends Thread {
        public void run() {
            for (int i = 0; i < 5; i++) {
                try {
                    Thread.sleep(1000); 
                    synchronized (lock) {
                        count++;
                        System.out.println("Thread A: " + count);
                        lock.notify(); 
                        lock.wait(); 
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static class ThreadB extends Thread {
        public void run() {
            for (int i = 0; i < 5; i++) {
                synchronized (lock) {
                    try {
                        System.out.println("Thread B: " + count);
                        lock.notify(); 
                        lock.wait(); 
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        ThreadA threadA = new ThreadA();
        ThreadB threadB = new ThreadB();

        threadA.start();
        threadB.start();
    }

}
