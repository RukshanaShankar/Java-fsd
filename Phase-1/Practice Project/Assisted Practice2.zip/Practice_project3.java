package java_fsd2;

public class Practice_project3 {
	private static int count = 0;

    static class IncrementThread extends Thread {
        public void run() {
            for (int i = 0; i < 10000; i++) {
                increment();
            }
        }
    }

    static synchronized void increment() {
        count++;
    }

    public static void main(String[] args) throws InterruptedException {
        IncrementThread thread1 = new IncrementThread();
        IncrementThread thread2 = new IncrementThread();

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();

        System.out.println("Final count: " + count);
    }
	

}
