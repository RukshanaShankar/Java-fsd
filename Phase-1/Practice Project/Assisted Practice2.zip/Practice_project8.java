package java_fsd2;
//Abstraction 
abstract class Animal {
    private String name;

    public Animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract void makeSound(); // Abstract method
}

//Inheritance
class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " barks.");
    }
}
//Encapsulation

class volunteer
{
	private String name;
	private int id;
	public volunteer(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}

//Polymorphism

class AnimalShelter
{
	public void makeAnimalSound(Animal animal) {
        animal.makeSound();
    }
}

public class Practice_project8 {
	public static void main(String[] args) {
        // Creating objects
        Dog dog = new Dog("coco");
        volunteer v = new volunteer("sri",123);
        
        System.out.println("Volunteer name:"+ v.getName());
        System.out.println("Volunteer id:"+ v.getId());
        
        AnimalShelter shelter = new AnimalShelter();
        shelter.makeAnimalSound(dog); 
	}

}
