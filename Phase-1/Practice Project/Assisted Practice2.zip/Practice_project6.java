package java_fsd2;

import java.util.Scanner;

public class Practice_project6 {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        try {
	            System.out.print("Enter two number: ");
	            int x = sc.nextInt();
	            int y = sc.nextInt();

	            int result = divide(x, y);
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Error: " + e.getMessage());
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        } finally {
	            sc.close();
	            System.out.println("This is finally block");
	        }
	    }

	    public static int divide(int a, int b) throws ArithmeticException {
	        if (b == 0) {
	            throw new ArithmeticException("Division by zero is not allowed.");
	        }
	        return a / b;
	    }

}
