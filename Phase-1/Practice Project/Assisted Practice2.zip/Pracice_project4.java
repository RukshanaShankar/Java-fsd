package java_fsd2;

import java.util.Scanner;

public class Pracice_project4 {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		try
		{
			System.out.println("enter two  numerical values for multiplication");
			int x=sc.nextInt();
			int y = sc.nextInt();
			
			int mul = x*y;
			System.out.println("The multiplied value is:"+mul);
			
		}
		catch(Exception e)
		{
			System.err.println("invalid input");
			System.out.println(e);
		}
		
	}

}
