package java_fsd2;


interface Father  {
    default void display() {
        System.out.println("Father");
    }
}

interface Mother {
    default void display() {
        System.out.println("Mother");
    }
}
class Child implements Father,Mother {
    @Override
    public void display() {
        Father.super.display();
        Mother.super.display();
    }
}
public class Practice_project9 {
	public static void main(String[] args) {
        Child obj = new Child();
        obj.display(); 
        }

}
