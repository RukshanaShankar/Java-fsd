package java_fsd2;

public class InvalidAgeException extends Exception
{
public InvalidAgeException()
{
	System.out.println("Invalid age, not eligible for voterid");
}
}
