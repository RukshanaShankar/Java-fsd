package java_fsd4;

public class Project3 {
	public static int binarySearch(int[] arr, int target, int left, int right) {
        if (right >= left) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; // return the index if the target is found
            } else if (arr[mid] < target) {
                return binarySearch(arr, target, mid + 1, right); // search the right half
            } else {
                return binarySearch(arr, target, left, mid - 1); // search the left half
            }
        }

        return -1; // return -1 if the target is not found in the array
    }

    public static int exponentialSearch(int[] arr, int target) {
        if (arr[0] == target) {
            return 0; // return 0 if the target is found at the first element
        }

        int i = 1;
        while (i < arr.length && arr[i] <= target) {
            i *= 2;
        }

        return binarySearch(arr, target, i / 2, Math.min(i, arr.length - 1));
    }

    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        int target = 50;
        int result = exponentialSearch(arr, target);
        if (result != -1) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
