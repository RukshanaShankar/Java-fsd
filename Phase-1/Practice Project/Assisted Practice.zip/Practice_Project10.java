package java_fsd;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practice_Project10 {
	public static void main(String[] args) {
        String input1 = "Hello, World!";
        String input2 = "12345";
        
        
        String pattern1 = "^[A-Za-z\\s,]+!$"; 
        String pattern2 = "\\d+"; 
        
        
        Pattern p1 = Pattern.compile(pattern1);
        Matcher m1 = p1.matcher(input1);
        System.out.println("Pattern 1 matches input 1: " + m1.matches());
        
        
        Pattern p2 = Pattern.compile(pattern2);
        Matcher m2 = p2.matcher(input2);
        System.out.println("Pattern 2 matches input 2: " + m2.matches());
    }

}
