package java_fsd;

public class Practice_Project7 {

	private int outer = 123;

    // Inner class
    public class InnerClass {
        public void display() {
            System.out.println("Inner class accessing outer class attribute: " + outer);
        }
    }

    public static void main(String[] args) {
    	Practice_Project7 outerObj = new Practice_Project7();
        
        // Creating an instance of the inner class
    	Practice_Project7.InnerClass innerObj = outerObj.new InnerClass();
        
        // Accessing the inner class method
        innerObj.display();
    }
}
