package java_fsd;

public class Practice_Project9 {
	public static void main(String[] args) {
	      
        int[] arr = {15, 10, 35, 25, 50, 40};
        System.out.println("Array Size:"+arr.length);
        System.out.println("One dimensional array:");
        
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println("Two dimensional array size:"+matrix.length);
        System.out.println("Two dimensional array");
        
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
    }

}
