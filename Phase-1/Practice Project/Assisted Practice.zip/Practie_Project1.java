package java_fsd;

public class Practie_Project1 {
	public static void main(String[] args)
	{   byte b= 50;
	    short s = b;
		int val= s;
		long l=val;
		float f = l;
		double d = f;
		
		System.out.println("Final value after Implicit typecasting is:"+d);
		
		double d1=15.50;
		int num = (int)d1;
		System.out.println("Final value after Explicit typecasting is:"+num);
		
	}
}
