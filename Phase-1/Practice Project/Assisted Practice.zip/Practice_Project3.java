package java_fsd;

public class Practice_Project3 {

	public void greet() {
        System.out.println("Hello!");
    }

    public int add(int a, int b) {
    	System.out.println("Method with parameter and return type");
    	   
        return a + b;
    }
    
    public void display(String str) {
         System.out.println("Method with parameter and no return type"+" "+str);
    }

    public static void main(String[] args) {
        Practice_Project3 p = new Practice_Project3();

        
        p.greet();
        
        p.display("hello");
        int result = p.add(15, 3);
        System.out.println("Result: " + result);
    }
}
