package java_fsd;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Practice_Project6 {

	public static void main(String[] args)
	{
		Map<String, Integer> map = new HashMap<>();

        // Adding key-value pairs to the map
        map.put("Alice", 25);
        map.put("Bob", 30);
        map.put("Charlie", 28);
        Scanner sc = new Scanner(System.in);

        // Displaying the elements of the map
        System.out.println("Map elements:");
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
	}
	}
}
