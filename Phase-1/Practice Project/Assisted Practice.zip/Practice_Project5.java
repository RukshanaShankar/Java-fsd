package java_fsd;

import java.util.HashMap;
import java.util.HashSet;

import java.util.Map;

public class Practice_Project5 {
	public static void main(String[] args)
	{
		
		Map<Integer, String> hm = new HashMap<>();
        hm.put(1, "Apple");
        hm.put(2, "Orange");
        System.out.println("The HashMap: " + hm);

        HashSet<String> hs = new HashSet<>();
        
        hs.add("dilip");
        hs.add("abay");
        hs.add("swetha");
        System.out.println("The HashSet:"+hs);
        
		
	}
	

}
