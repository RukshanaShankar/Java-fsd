package java_fsd;

public class Practice_Project8 {
	public static void main(String[] args) {
        // Create a string
        String originalString = "Hello, World!";
        
        // Convert string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);
        
        // Convert string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);
        
        // Display the original string, StringBuffer, and StringBuilder
        System.out.println("Original String: " + originalString);
        System.out.println("StringBuffer: " + stringBuffer);
        System.out.println("StringBuilder: " + stringBuilder);
    }

}
