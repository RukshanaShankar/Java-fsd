package java_fsd;

public class Practice_Project4 {

	String name;
	int age;
	int id;
	
	public Practice_Project4() {
		System.out.println("This is a default constructor");
	}
	public Practice_Project4(String name, int age, int id) {
		this.name = name;
		this.age = age;
		this.id = id;
		
		System.out.println("the parameters are:"+this.name+" "+this.age+" "+this.id);
	}
	

	public static void main(String[]args)
	{
		Practice_Project4 p = new Practice_Project4();
		Practice_Project4 p1 = new Practice_Project4("John",25,1442);
		
	}
}
