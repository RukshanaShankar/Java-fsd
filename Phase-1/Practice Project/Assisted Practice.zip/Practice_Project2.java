package java_fsd;


class DefaultClass {
    void display() {
        System.out.println("This is a default class.");
    }
}

// Class with private access modifier
class PrivateClass {
    private void display() {
        System.out.println("This is a private class.");
        
        PrivateClass p = new PrivateClass();
        p.display();
    }
}
class ProtectedClass {
    private void display() {
        System.out.println("This is a Protected Class.");
        
        ProtectedClass pr = new ProtectedClass();
        pr.display();
    }
}
public class Practice_Project2 {
	public void display() {
        System.out.println("This is a public class.");
    }
	
	public static void main(String[] args)
	{
		Practice_Project2 publicObj = new Practice_Project2();
        publicObj.display();

        DefaultClass defaultObj = new DefaultClass();
        defaultObj.display();
        
        //PrivateClass p = new PrivateClass();
        //object can be created but cannot access method outside that class
        //p.display();
        
        //object can be created but cannot access method outside that class
        //ProtectedClass pr = new ProtectedClass();
        //pr.display();
        
	
}

}
