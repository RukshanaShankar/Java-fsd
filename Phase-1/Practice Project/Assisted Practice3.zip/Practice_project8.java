package java_fsd3;

class stack{
	int n;
    int arr[];
    int top;
    
    public stack(int n)
    { this.n=n;
      this.arr= new int[n];
      top=-1;
    }
    public void display() {
        for (int i = 0; i <= top; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    public boolean isFull()
    {   
		return (n-1 ==top);
    	
    }
    public boolean isEmpty()
    {   
		return (top== -1);
    	
    }
    public void push(int n)
    {  if(isFull())
    {
    	System.out.println("Stack is full");
    }else
    {
    	top++;
    	arr[top] = n;
    }
    }
    public int pop()
    {
    	if(isEmpty())
    	{
    		System.out.println("Stack is empty");
    		return -1;
    	}
    	else
    	{
    		int value = arr[top];
    		top--;
    		return value;
    	}
    }
}

public class Practice_project8 {
	public static void main(String[] args)
	{ stack s = new stack(4);
	  s.push(10);
	  s.push(20);
	  s.push(30);
	  s.push(40);
	  
	  System.out.println("After pusing 4 elements");
	  s.display();
	  s.pop();
	  System.out.println("After a Pop");
	  s.display();
	
	}

}
