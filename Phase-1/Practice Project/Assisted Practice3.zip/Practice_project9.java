package java_fsd3;

class queue 
{
	int front=-1;
	int rear=-1;
	int arr[];
	int n;
	public queue(int n)
	{
		this.n = n;
		arr = new int[n]; 
	}
	public boolean isFull()
	{
		return rear== n-1;
	}
	public boolean isEmpty()
	{
		return front== -1 && rear== -1;
	}
	public void enqueue(int data)
	{
		if(isFull())
		{
			System.out.println("Queue is full");
		}
		else if(isEmpty())
		{
			rear = front =0;
			arr[rear] = data;
		}
		else
		{
			rear++;
			arr[rear] = data;
		}
	}
	public int dequeue()
	{
		if(isEmpty())
		{   System.out.println("Queue is empty");
			return -1;
		}
		else if (front== rear)
		{
			int top = arr[front];
			front = rear = -1;
			return top;
		}
		else
		{
			int top = arr[front];
			front++;
			return top;
		}
	}
	public void display()
	{
		for(int i= this.front;i<= this.rear;i++)
		{
			System.out.print(" " +arr[i]);
		}
	}
}

public class Practice_project9 {
	public static void main(String[]srgs)
	{
		queue q = new queue(10);
		  
		  
		  q.enqueue(10);
		  q.enqueue(20);
		  q.enqueue(30);
		  q.enqueue(40);
		  q.enqueue(50);
		  q.enqueue(60);
		  q.enqueue(70);
		  q.enqueue(80);
		  q.enqueue(90);
		  q.enqueue(100);
		  q.display();
		  
		  q.dequeue();
		  q.dequeue();
		  System.out.println();
		  System.out.println("After dequeue, the elements are:");
		  q.display();
		    
	}

}
