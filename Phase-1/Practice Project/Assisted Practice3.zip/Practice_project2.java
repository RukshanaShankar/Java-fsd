package java_fsd3;

import java.util.Arrays;

public class Practice_project2 {
	public static void main(String[] args) {
        int[] list = {12,34,10,48,97,56,70};
        int n = list.length;

        System.out.println("Unsorted list: " + Arrays.toString(list));

        int fourthSmallest = findFourthSmallest(list, n);
        System.out.println("Fourth smallest element: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] list, int n) {
        // Sort the list in ascending order
        Arrays.sort(list);

        // Return the fourth element (index 3) as the fourth smallest
        return list[3];
    }
	
}
