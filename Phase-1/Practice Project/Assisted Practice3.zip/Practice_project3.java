package java_fsd3;

import java.util.Scanner;

public class Practice_project3 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the value of n: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.print("Enter the value of L: ");
        int L = sc.nextInt();

        System.out.print("Enter the value of R: ");
        int R = sc.nextInt();

        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range!");
            return;
        }

        int sum = calculateSum(arr, L, R);
        System.out.println("Sum of elements in the range [" + L + ", " + R + "] is: " + sum);
    }

    public static int calculateSum(int[] arr, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}


