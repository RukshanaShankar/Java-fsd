package java_fsd3;

class CircularLinkedList {
    Node head;

    CircularLinkedList() {
        head = null;
    }

    // Function to insert a new node in a sorted circular linked list
    void insertSorted(int data) {
        Node newNode = new Node(data);

        // Case 1: List is empty
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
            return;
        }

        // Case 2: List has only one node
        if (head.next == head) {
            newNode.next = head;
            head.next = newNode;
            head = newNode;
            return;
        }

        // Case 3: List has more than one node
        Node current = head;
        Node prev = null;

        // Find the correct position to insert the new node
        do {
            prev = current;
            current = current.next;

            // Insert at the beginning of the list
            if (current.data >= newNode.data && current == head) {
                newNode.next = current;
                prev.next = newNode;
                head = newNode;
                return;
            }
            // Insert in the middle or at the end of the list
            else if (prev.data <= newNode.data && current.data >= newNode.data) {
                prev.next = newNode;
                newNode.next = current;
                return;
            }

        } while (current != head);

        // Insert at the end of the list
        prev.next = newNode;
        newNode.next = head;
    }

    // Function to print the circular linked list
    void printList() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}


public  class Practice_project6 {
	public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insertSorted(5);
        list.insertSorted(2);
        list.insertSorted(8);
        list.insertSorted(1);
        list.insertSorted(7);

        System.out.println("Sorted Circular Linked List:");
        list.printList();
    }

}

